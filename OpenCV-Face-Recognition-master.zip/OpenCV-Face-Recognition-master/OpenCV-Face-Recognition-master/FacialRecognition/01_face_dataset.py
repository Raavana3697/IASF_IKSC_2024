import cv2
import os

# Open a connection to the default camera (index 0)
cam = cv2.VideoCapture(0)
cam.set(3, 640)  # Set video width
cam.set(4, 480)  # Set video height

# Load the Haar Cascade classifier for face detection
face_detector = cv2.CascadeClassifier(r'C:\Users\aruns\Desktop\OpenCV-Face-Recognition-master\FaceDetection\Cascades\haarcascade_frontalface_default.xml')

# For each person, enter one numeric face id
face_id = input('\nEnter user ID and press <return> ==> ')

print("\n[INFO] Initializing face capture. Look at the camera and wait ...")
# Initialize individual sampling face count
count = 0

# Create dataset directory if it doesn't exist
if not os.path.exists('dataset'):
    os.makedirs('dataset')

while True:
    ret, img = cam.read()
    if not ret:
        print("Failed to grab frame")
        break
    
    img = cv2.flip(img, 1)  # Flip video image horizontally for a mirror effect
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # Convert to grayscale for face detection

    # Detect faces
    faces = face_detector.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    for (x, y, w, h) in faces:
        cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)     
        count += 1

        # Save the captured image into the datasets folder
        cv2.imwrite(f"dataset/User.{str(face_id)}.{str(count)}.jpg", gray[y:y + h, x:x + w])
        cv2.imshow('image', img)

    # Display the video feed
    cv2.imshow('Face Capture', img)

    k = cv2.waitKey(100) & 0xff  # Press 'ESC' for exiting video
    if k == 27:  # Exit if ESC is pressed
        break
    elif count >= 30:  # Take 30 face samples and stop video
        break

# Cleanup
print("\n[INFO] Exiting program and cleaning up...")
cam.release()
cv2.destroyAllWindows()
