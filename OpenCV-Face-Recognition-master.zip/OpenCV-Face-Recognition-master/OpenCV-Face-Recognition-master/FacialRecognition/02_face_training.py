import cv2
import numpy as np
from PIL import Image
import os

# Path for the dataset
dataset_path = r"C:\Users\aruns\Desktop\OpenCV-Face-Recognition-master\dataset"
recognizer = cv2.face.LBPHFaceRecognizer_create()
faceCascade = cv2.CascadeClassifier(r"C:\Users\aruns\Desktop\OpenCV-Face-Recognition-master\FaceDetection\Cascades\haarcascade_frontalface_default.xml")

# Get images and labels for training
def get_images_and_labels(path):
    image_paths = [os.path.join(path, f) for f in os.listdir(path)]
    face_samples = []
    ids = []

    for image_path in image_paths:
        # Convert the image to grayscale
        img = Image.open(image_path).convert('L')
        img_np = np.array(img, 'uint8')

        # Extract the user ID from the image filename
        face_id = int(os.path.split(image_path)[-1].split(".")[1])
        faces = faceCascade.detectMultiScale(img_np)

        for (x, y, w, h) in faces:
            face_samples.append(img_np[y:y + h, x:x + w])
            ids.append(face_id)

    return face_samples, ids

print("Training faces. It will take a few seconds. Wait...")

faces, ids = get_images_and_labels(dataset_path)
recognizer.train(faces, np.array(ids))

# Save the trained model
model_path = r"C:\Users\aruns\Desktop\OpenCV-Face-Recognition-master\FacialRecognition\trainer\trainer.yml"
if not os.path.exists(os.path.dirname(model_path)):
    os.makedirs(os.path.dirname(model_path))

recognizer.write(model_path)
print(f"Model trained and saved at {model_path}")
